ОСКОЛКИ БЕЗДНЫ — Android-проект

Это исходный проект Android Studio, оборачивающий игру в WebView.
Готовый APK в этой среде собрать не удалось: Android SDK и Gradle здесь не установлены.

Как получить APK:
1. Установи Android Studio на ПК.
2. Открой папку OskolkiBezDny_Android.
3. Дождись синхронизации Gradle.
4. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Минимальная версия Android: 6.0 (API 23).
Интернет игре не нужен. Прогресс сохраняется в локальном хранилище WebView.
